from WeatherAPIXU import *
__version__ = "0.0.1"

# import all

__ALL__ = ['WeatherAPIXU']

